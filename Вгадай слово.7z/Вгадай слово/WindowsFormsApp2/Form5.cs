﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        int click = 0;
        int score;
        public string[] newArr4 { get; set; }
        public Form5(int score1)
        {
            score = score1;
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            List<char> ltrsLst = new List<char>(newArr4[0]);
            var rnd = new Random();
            while (ltrsLst.Count > 0)
            {
                int index = rnd.Next(0, ltrsLst.Count);
                label2.Text += Convert.ToString((ltrsLst[index]) + " ");
                ltrsLst.RemoveAt(index);
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == newArr4[0])
            {
                if (click != 1)
                {
                    score++;
                }
            }
                string one = " бал";
                string two = " бала";
                string five = " балів";
                if (score == 1)
                {
                    MessageBox.Show("Вітаю, Ви набрали" + score + one);
                    Application.Exit();
                }
                else if (score >= 2 && score <= 4)
                {
                    MessageBox.Show("Вітаю, Ви набрали " + score + two);
                    Application.Exit();
                }
                else
                    MessageBox.Show("Вітаю, Ви набрали " + score + five);
                Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = newArr4[0];
            click = 1;
        }
    }
}
